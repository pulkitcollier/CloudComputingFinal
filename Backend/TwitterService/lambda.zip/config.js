"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.watsonConfig = [{
        username: "56ae05c5-98e0-4b94-9fe2-2dc28c2cfb22",
        password: "vP0nVhyNHZuC",
        version_date: '2017-02-27'
    }, {
        username: "bbd6c982-a42d-482a-ae43-f3fb8ba9f01c",
        password: "Ux7rF02j1X81",
        version_date: '2017-02-27'
    }, {
        username: "ddff9a75-d622-4ade-a70e-132894cf6724",
        password: "yItlChKXBnoh",
        version_date: '2017-02-27'
    }, {
        username: "7cd8b87b-0010-4375-a6e4-ccc3ead9c5f1",
        password: "aktgcC42XxyZ",
        version_date: '2017-02-27'
    }, {
        username: "ce201043-4011-4327-8fbe-b6d6ae3983ea",
        password: "Bar1pJhIA1iq",
        version_date: '2017-02-27'
    }
];
